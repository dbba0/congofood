import React, { useEffect, useRef } from 'react';
import { Animated, View, type ViewStyle } from 'react-native';

export interface SkeletonLoaderProps {
  width?: number | string;
  height?: number;
  borderRadius?: number;
  style?: ViewStyle;
}

export function SkeletonLoader({
  width = '100%',
  height = 16,
  borderRadius = 6,
  style,
}: SkeletonLoaderProps) {
  const anim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(anim, { toValue: 1, duration: 900, useNativeDriver: true }),
        Animated.timing(anim, { toValue: 0, duration: 900, useNativeDriver: true }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [anim]);

  const opacity = anim.interpolate({ inputRange: [0, 1], outputRange: [0.35, 0.7] });

  return (
    <Animated.View
      style={[
        styles.base,
        { width: width as number, height, borderRadius, opacity },
        style,
      ]}
    />
  );
}

/** Skeleton pour RestaurantCard variant="list" (horizontale) */
export function SkeletonRestaurantCard() {
  return (
    <View style={styles.card}>
      <SkeletonLoader width={60} height={60} borderRadius={10} />
      <View style={styles.cardLines}>
        <SkeletonLoader height={14} borderRadius={4} />
        <SkeletonLoader width="60%" height={11} borderRadius={4} />
        <SkeletonLoader width="80%" height={11} borderRadius={4} />
      </View>
    </View>
  );
}

/** Skeleton pour RestaurantCard variant="grid" (grille 2 colonnes) */
export function SkeletonRestaurantGridCard() {
  return (
    <View style={styles.gridCard}>
      <SkeletonLoader height={140} borderRadius={0} />
      <View style={styles.gridCardLines}>
        <SkeletonLoader height={14} borderRadius={4} />
        <SkeletonLoader width="50%" height={10} borderRadius={4} />
        <SkeletonLoader width="70%" height={10} borderRadius={4} />
      </View>
    </View>
  );
}

const styles = {
  base: {
    backgroundColor: '#2D2D3D',
  },
  // Skeleton list
  card: {
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
    gap: 12,
    padding: 12,
    backgroundColor: '#1A1A2E',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#2D2D3D',
  },
  cardLines: {
    flex: 1,
    gap: 8,
  },
  // Skeleton grid
  gridCard: {
    flex: 1,
    backgroundColor: '#1A1A2E',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: '#2D2D3D',
    overflow: 'hidden' as const,
  },
  gridCardLines: {
    padding: 12,
    gap: 8,
  },
};
