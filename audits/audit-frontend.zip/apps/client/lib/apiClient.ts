// Client HTTP avec injection automatique du token et logique de refresh
import { StorageService, STORAGE_KEYS } from './storage';
import { API } from '../constants/api';
import type { ApiResponse, AuthTokens } from '@wapi/types';

// Indicateur pour éviter les boucles infinies de refresh
let isRefreshing = false;
let refreshQueue: Array<(token: string) => void> = [];

function drainQueue(token: string) {
  refreshQueue.forEach((resolve) => resolve(token));
  refreshQueue = [];
}

async function refreshTokens(): Promise<string | null> {
  const refreshToken = await StorageService.get(STORAGE_KEYS.REFRESH_TOKEN);
  if (!refreshToken) return null;

  try {
    const res = await fetch(API.refresh, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ refreshToken }),
    });
    if (!res.ok) return null;
    const data: ApiResponse<{ tokens: AuthTokens }> = await res.json();
    if (!data.success || !data.data) return null;

    const { accessToken, refreshToken: newRefresh } = data.data.tokens;
    await StorageService.set(STORAGE_KEYS.ACCESS_TOKEN, accessToken);
    await StorageService.set(STORAGE_KEYS.REFRESH_TOKEN, newRefresh);
    return accessToken;
  } catch {
    return null;
  }
}

export async function apiRequest<T>(
  url: string,
  options: RequestInit = {}
): Promise<T> {
  const accessToken = await StorageService.get(STORAGE_KEYS.ACCESS_TOKEN);

  // Debug — supprimer après vérification
  console.log('[API] Token utilisé:', accessToken?.slice(0, 20));
  console.log('[API] Request URL:', url);

  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    ...(options.headers as Record<string, string>),
  };
  if (accessToken) headers['Authorization'] = `Bearer ${accessToken}`;

  // Timeout 30 secondes — réseau 3G instable à Kinshasa
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 30000);

  let response = await fetch(url, { ...options, headers, signal: controller.signal });
  clearTimeout(timeoutId);

  // Debug — supprimer après vérification
  console.log('[API] Response status:', response.status);

  // Si 401 → vérifier si c'est un token dev (pas de refresh possible)
  if (response.status === 401) {
    // Token dev → pas de refresh, on laisse passer sans logout
    if (accessToken?.startsWith('dev-token-')) {
      console.warn('[API] Token dev rejeté (401) — requête auth ignorée pour:', url);
      // Retourner la réponse telle quelle, le json sera parsé plus bas
    } else if (isRefreshing) {
      const newToken = await new Promise<string>((resolve) => {
        refreshQueue.push(resolve);
      });
      headers['Authorization'] = `Bearer ${newToken}`;
      const retryCtrl = new AbortController();
      const retryTimeout = setTimeout(() => retryCtrl.abort(), 30000);
      response = await fetch(url, { ...options, headers, signal: retryCtrl.signal });
      clearTimeout(retryTimeout);
    } else {
      isRefreshing = true;
      const newToken = await refreshTokens();
      isRefreshing = false;

      if (newToken) {
        drainQueue(newToken);
        headers['Authorization'] = `Bearer ${newToken}`;
        const retryCtrl = new AbortController();
        const retryTimeout = setTimeout(() => retryCtrl.abort(), 30000);
        response = await fetch(url, { ...options, headers, signal: retryCtrl.signal });
        clearTimeout(retryTimeout);
      } else {
        StorageService.clearAuth();
        throw new Error('SESSION_EXPIRED');
      }
    }
  }

  const json: ApiResponse<T> = await response.json();

  if (!response.ok || !json.success) {
    throw new Error(json.message || `Erreur ${response.status}`);
  }

  return json.data as T;
}
